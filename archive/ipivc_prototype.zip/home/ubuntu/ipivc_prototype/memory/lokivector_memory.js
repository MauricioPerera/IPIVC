/**
 * LokiVector Memory System - Nivel 1 (Memoria de Proyecto)
 * 
 * Este módulo implementa un sistema de memoria persistente basado en LokiVector
 * para almacenar y recuperar conocimiento del proyecto a través de búsqueda vectorial.
 */

const Loki = require('lokijs');
const fs = require('fs');
const path = require('path');

class LokiVectorMemory {
  /**
   * Inicializa el sistema de memoria con LokiVector
   * @param {string} dbPath - Ruta donde se persistirá la base de datos
   */
  constructor(dbPath = './memory/project_memory.db') {
    this.dbPath = dbPath;
    this.db = null;
    this.collection = null;
    this.initialized = false;
  }

  /**
   * Inicializa la base de datos de LokiVector
   */
  async init() {
    return new Promise((resolve, reject) => {
      this.db = new Loki(this.dbPath, {
        autoload: true,
        autoloadCallback: () => {
          this._setupCollection();
          this.initialized = true;
          resolve();
        },
        autosave: true,
        autosaveInterval: 5000, // Guardar cada 5 segundos
      });
    });
  }

  /**
   * Configura la colección de memoria si no existe
   */
  _setupCollection() {
    this.collection = this.db.getCollection('project_knowledge');
    
    if (!this.collection) {
      this.collection = this.db.addCollection('project_knowledge', {
        indices: ['id', 'type', 'timestamp'],
      });
    }
  }

  /**
   * Almacena un fragmento de conocimiento con su embedding
   * @param {object} knowledge - Objeto con propiedades: id, type, content, embedding, metadata
   */
  storeKnowledge(knowledge) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    const record = {
      id: knowledge.id || this._generateId(),
      type: knowledge.type, // 'spec', 'skill', 'tool', 'guideline', 'pattern'
      content: knowledge.content,
      embedding: knowledge.embedding, // Array de números (vector)
      metadata: knowledge.metadata || {},
      timestamp: new Date().toISOString(),
      version: knowledge.version || 1,
    };

    this.collection.insert(record);
    return record;
  }

  /**
   * Busca conocimiento similar usando similitud de coseno en embeddings
   * @param {array} queryEmbedding - Vector de embedding de la consulta
   * @param {string} type - Tipo de conocimiento a buscar (opcional)
   * @param {number} topK - Número de resultados a retornar
   * @returns {array} Resultados ordenados por similitud
   */
  searchSimilar(queryEmbedding, type = null, topK = 5) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    let candidates = this.collection.find();
    
    if (type) {
      candidates = candidates.filter(doc => doc.type === type);
    }

    // Calcular similitud de coseno para cada documento
    const results = candidates.map(doc => ({
      ...doc,
      similarity: this._cosineSimilarity(queryEmbedding, doc.embedding),
    }));

    // Ordenar por similitud descendente
    results.sort((a, b) => b.similarity - a.similarity);

    return results.slice(0, topK);
  }

  /**
   * Calcula la similitud de coseno entre dos vectores
   * @param {array} vec1 - Primer vector
   * @param {array} vec2 - Segundo vector
   * @returns {number} Similitud entre 0 y 1
   */
  _cosineSimilarity(vec1, vec2) {
    if (vec1.length !== vec2.length) {
      throw new Error('Vectors must have the same length');
    }

    let dotProduct = 0;
    let magnitude1 = 0;
    let magnitude2 = 0;

    for (let i = 0; i < vec1.length; i++) {
      dotProduct += vec1[i] * vec2[i];
      magnitude1 += vec1[i] * vec1[i];
      magnitude2 += vec2[i] * vec2[i];
    }

    magnitude1 = Math.sqrt(magnitude1);
    magnitude2 = Math.sqrt(magnitude2);

    if (magnitude1 === 0 || magnitude2 === 0) {
      return 0;
    }

    return dotProduct / (magnitude1 * magnitude2);
  }

  /**
   * Obtiene un documento de conocimiento por ID
   * @param {string} id - ID del documento
   * @returns {object} Documento encontrado o null
   */
  getKnowledgeById(id) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    const results = this.collection.find({ id });
    return results.length > 0 ? results[0] : null;
  }

  /**
   * Actualiza un documento de conocimiento existente
   * @param {string} id - ID del documento
   * @param {object} updates - Propiedades a actualizar
   */
  updateKnowledge(id, updates) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    const doc = this.getKnowledgeById(id);
    if (!doc) {
      throw new Error(`Knowledge with id ${id} not found`);
    }

    const updated = {
      ...doc,
      ...updates,
      timestamp: new Date().toISOString(),
      version: (doc.version || 1) + 1,
    };

    this.collection.update(updated);
    return updated;
  }

  /**
   * Elimina un documento de conocimiento
   * @param {string} id - ID del documento
   */
  deleteKnowledge(id) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    const doc = this.getKnowledgeById(id);
    if (!doc) {
      throw new Error(`Knowledge with id ${id} not found`);
    }

    this.collection.remove(doc);
  }

  /**
   * Lista todos los documentos de un tipo específico
   * @param {string} type - Tipo de conocimiento
   * @returns {array} Documentos del tipo especificado
   */
  listByType(type) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    return this.collection.find({ type });
  }

  /**
   * Exporta la base de datos a un archivo JSON
   * @param {string} filePath - Ruta del archivo de exportación
   */
  exportToJSON(filePath) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    const data = this.collection.find();
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  }

  /**
   * Importa conocimiento desde un archivo JSON
   * @param {string} filePath - Ruta del archivo de importación
   */
  importFromJSON(filePath) {
    if (!this.initialized) {
      throw new Error('Memory system not initialized. Call init() first.');
    }

    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    data.forEach(item => this.storeKnowledge(item));
  }

  /**
   * Genera un ID único
   * @returns {string} ID único
   */
  _generateId() {
    return `knowledge_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Cierra la base de datos
   */
  close() {
    if (this.db) {
      this.db.close();
      this.initialized = false;
    }
  }
}

module.exports = LokiVectorMemory;
