/**
 * Agent-User Memory System - Nivel 2 (Memoria de Sesión)
 * 
 * Este módulo implementa un sistema de memoria volátil para la interacción
 * actual entre el agente y el usuario. Se reinicia con cada nueva sesión.
 */

class AgentUserMemory {
  /**
   * Inicializa la memoria de agente-usuario
   */
  constructor() {
    this.conversationHistory = [];
    this.uploadedFiles = [];
    this.taskProgress = {};
    this.userPreferences = {};
    this.sessionMetadata = {
      startTime: new Date(),
      sessionId: this._generateSessionId(),
    };
  }

  /**
   * Almacena un mensaje en el historial de conversación
   * @param {string} role - 'user' o 'agent'
   * @param {string} content - Contenido del mensaje
   * @param {object} metadata - Metadatos adicionales (opcional)
   */
  addMessage(role, content, metadata = {}) {
    const message = {
      role,
      content,
      timestamp: new Date().toISOString(),
      ...metadata,
    };

    this.conversationHistory.push(message);
    return message;
  }

  /**
   * Obtiene el historial de conversación completo
   * @returns {array} Historial de mensajes
   */
  getConversationHistory() {
    return this.conversationHistory;
  }

  /**
   * Obtiene los últimos N mensajes
   * @param {number} count - Número de mensajes a retornar
   * @returns {array} Últimos N mensajes
   */
  getRecentMessages(count = 10) {
    return this.conversationHistory.slice(-count);
  }

  /**
   * Registra un archivo subido
   * @param {object} file - Objeto con propiedades: name, path, type, uploadedAt
   */
  addUploadedFile(file) {
    const fileRecord = {
      id: this._generateId(),
      name: file.name,
      path: file.path,
      type: file.type,
      uploadedAt: new Date().toISOString(),
      ...file,
    };

    this.uploadedFiles.push(fileRecord);
    return fileRecord;
  }

  /**
   * Obtiene todos los archivos subidos en la sesión
   * @returns {array} Lista de archivos
   */
  getUploadedFiles() {
    return this.uploadedFiles;
  }

  /**
   * Actualiza el progreso de una tarea
   * @param {string} taskId - Identificador de la tarea
   * @param {object} progress - Objeto con propiedades: status, completedSteps, totalSteps, details
   */
  updateTaskProgress(taskId, progress) {
    this.taskProgress[taskId] = {
      taskId,
      status: progress.status || 'in_progress', // 'pending', 'in_progress', 'completed', 'failed'
      completedSteps: progress.completedSteps || 0,
      totalSteps: progress.totalSteps || 0,
      details: progress.details || {},
      lastUpdated: new Date().toISOString(),
    };

    return this.taskProgress[taskId];
  }

  /**
   * Obtiene el progreso de una tarea específica
   * @param {string} taskId - Identificador de la tarea
   * @returns {object} Progreso de la tarea
   */
  getTaskProgress(taskId) {
    return this.taskProgress[taskId] || null;
  }

  /**
   * Obtiene el progreso de todas las tareas
   * @returns {object} Progreso de todas las tareas
   */
  getAllTaskProgress() {
    return this.taskProgress;
  }

  /**
   * Almacena una preferencia del usuario
   * @param {string} key - Clave de la preferencia
   * @param {*} value - Valor de la preferencia
   */
  setUserPreference(key, value) {
    this.userPreferences[key] = {
      value,
      setAt: new Date().toISOString(),
    };

    return this.userPreferences[key];
  }

  /**
   * Obtiene una preferencia del usuario
   * @param {string} key - Clave de la preferencia
   * @returns {*} Valor de la preferencia o null
   */
  getUserPreference(key) {
    const pref = this.userPreferences[key];
    return pref ? pref.value : null;
  }

  /**
   * Obtiene todas las preferencias del usuario
   * @returns {object} Todas las preferencias
   */
  getAllUserPreferences() {
    const prefs = {};
    Object.keys(this.userPreferences).forEach(key => {
      prefs[key] = this.userPreferences[key].value;
    });
    return prefs;
  }

  /**
   * Obtiene metadatos de la sesión
   * @returns {object} Metadatos de la sesión
   */
  getSessionMetadata() {
    return {
      ...this.sessionMetadata,
      duration: new Date() - this.sessionMetadata.startTime,
      messageCount: this.conversationHistory.length,
      fileCount: this.uploadedFiles.length,
    };
  }

  /**
   * Exporta el estado actual de la memoria a un objeto JSON
   * @returns {object} Estado completo de la memoria
   */
  exportState() {
    return {
      conversationHistory: this.conversationHistory,
      uploadedFiles: this.uploadedFiles,
      taskProgress: this.taskProgress,
      userPreferences: this.getAllUserPreferences(),
      sessionMetadata: this.getSessionMetadata(),
    };
  }

  /**
   * Importa un estado previo de la memoria (para restaurar sesión)
   * @param {object} state - Estado a importar
   */
  importState(state) {
    if (state.conversationHistory) {
      this.conversationHistory = state.conversationHistory;
    }
    if (state.uploadedFiles) {
      this.uploadedFiles = state.uploadedFiles;
    }
    if (state.taskProgress) {
      this.taskProgress = state.taskProgress;
    }
    if (state.userPreferences) {
      Object.keys(state.userPreferences).forEach(key => {
        this.setUserPreference(key, state.userPreferences[key]);
      });
    }
  }

  /**
   * Limpia la memoria de sesión (reinicio)
   */
  clear() {
    this.conversationHistory = [];
    this.uploadedFiles = [];
    this.taskProgress = {};
    this.userPreferences = {};
    this.sessionMetadata = {
      startTime: new Date(),
      sessionId: this._generateSessionId(),
    };
  }

  /**
   * Genera un ID único
   * @returns {string} ID único
   */
  _generateId() {
    return `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Genera un ID de sesión único
   * @returns {string} ID de sesión
   */
  _generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

module.exports = AgentUserMemory;
