/**
 * Ejemplo de Uso del Sistema de Memoria IPIVC
 * 
 * Demuestra cómo integrar LokiVector (L1) y AgentUserMemory (L2)
 * en un flujo de trabajo IPIVC.
 */

const LokiVectorMemory = require('./lokivector_memory');
const AgentUserMemory = require('./agent_user_memory');

async function demonstrateIPIVCMemory() {
  console.log('=== Demostración del Sistema de Memoria IPIVC ===\n');

  // Inicializar ambos niveles de memoria
  const projectMemory = new LokiVectorMemory('./memory/project_memory.db');
  const agentUserMemory = new AgentUserMemory();

  // Inicializar la memoria de proyecto
  await projectMemory.init();
  console.log('✓ Memoria de Proyecto (L1) inicializada');
  console.log('✓ Memoria Agente-Usuario (L2) inicializada\n');

  // ========== FASE 1: INVESTIGA ==========
  console.log('--- FASE 1: INVESTIGA ---');
  
  // El agente consulta la memoria L1 para obtener especificaciones previas
  const existingSpecs = projectMemory.listByType('spec');
  console.log(`Especificaciones previas encontradas: ${existingSpecs.length}`);

  // El agente almacena el contexto de la sesión en L2
  agentUserMemory.addMessage('user', 'Necesito implementar un sistema de autenticación con JWT');
  agentUserMemory.addMessage('agent', 'Entendido. Voy a investigar las mejores prácticas y especificaciones previas.');
  
  // Simular búsqueda en L1
  const mockEmbedding = Array(10).fill(0).map(() => Math.random());
  const similarDocs = projectMemory.searchSimilar(mockEmbedding, 'spec', 3);
  console.log(`Documentos similares encontrados: ${similarDocs.length}\n`);

  // ========== FASE 2: PLANIFICA ==========
  console.log('--- FASE 2: PLANIFICA ---');

  // Crear una especificación formal
  const authSpec = {
    id: 'spec_auth_jwt_001',
    type: 'spec',
    content: `
# Especificación: Autenticación con JWT

## Requisitos
- Endpoint POST /api/auth/login
- Validar email y contraseña
- Retornar JWT token

## Criterios de Aceptación
- Given: Usuario válido
- When: POST /api/auth/login
- Then: Retorna token JWT con expiración de 24h
    `,
    embedding: mockEmbedding, // En producción, usar embeddings reales
    metadata: {
      author: 'agent_001',
      project: 'vibecoding_demo',
      priority: 'high',
    },
  };

  const storedSpec = projectMemory.storeKnowledge(authSpec);
  console.log(`✓ Especificación almacenada en L1: ${storedSpec.id}`);

  // Actualizar progreso en L2
  agentUserMemory.updateTaskProgress('task_auth_001', {
    status: 'in_progress',
    completedSteps: 1,
    totalSteps: 5,
    details: { phase: 'planning', specCreated: true },
  });

  console.log('✓ Progreso de tarea actualizado en L2\n');

  // ========== FASE 3: IMPLEMENTA ==========
  console.log('--- FASE 3: IMPLEMENTA ---');

  // El agente consulta la especificación de L1
  const retrievedSpec = projectMemory.getKnowledgeById('spec_auth_jwt_001');
  console.log(`✓ Especificación recuperada de L1: ${retrievedSpec.id}`);

  // Simular generación de código
  agentUserMemory.addMessage('agent', 'Generando código basado en la especificación...');
  agentUserMemory.addUploadedFile({
    name: 'auth.js',
    path: './src/auth.js',
    type: 'code',
  });

  agentUserMemory.updateTaskProgress('task_auth_001', {
    status: 'in_progress',
    completedSteps: 3,
    totalSteps: 5,
    details: { phase: 'implementation', codeGenerated: true },
  });

  console.log('✓ Código generado y registrado en L2\n');

  // ========== FASE 4: VERIFICA ==========
  console.log('--- FASE 4: VERIFICA ---');

  // Simular validación contra la especificación
  const taskProgress = agentUserMemory.getTaskProgress('task_auth_001');
  console.log(`Estado actual: ${taskProgress.status}`);
  console.log(`Progreso: ${taskProgress.completedSteps}/${taskProgress.totalSteps}`);

  agentUserMemory.addMessage('agent', 'Ejecutando pruebas de validación...');
  agentUserMemory.updateTaskProgress('task_auth_001', {
    status: 'in_progress',
    completedSteps: 4,
    totalSteps: 5,
    details: { phase: 'verification', testsRun: true, allTestsPassed: true },
  });

  console.log('✓ Verificación completada\n');

  // ========== FASE 5: CORRIGE (si es necesario) ==========
  console.log('--- FASE 5: CORRIGE ---');
  console.log('✓ No se encontraron discrepancias. Saltando fase de corrección.\n');

  // ========== FINALIZACIÓN ==========
  console.log('--- FINALIZACIÓN ---');

  agentUserMemory.updateTaskProgress('task_auth_001', {
    status: 'completed',
    completedSteps: 5,
    totalSteps: 5,
    details: { phase: 'completed', successfulDeployment: true },
  });

  // Promover conocimiento de L2 a L1
  const newSkill = {
    id: 'skill_jwt_validation_001',
    type: 'skill',
    content: 'Validación de JWT tokens con expiración',
    embedding: mockEmbedding,
    metadata: {
      promotedFrom: 'L2',
      promotionTime: new Date().toISOString(),
      confidence: 0.95,
    },
  };

  projectMemory.storeKnowledge(newSkill);
  console.log(`✓ Nuevo skill promovido de L2 a L1: ${newSkill.id}`);

  // Mostrar resumen de sesión
  const sessionMetadata = agentUserMemory.getSessionMetadata();
  console.log(`\n✓ Sesión completada`);
  console.log(`  - Duración: ${sessionMetadata.duration}ms`);
  console.log(`  - Mensajes: ${sessionMetadata.messageCount}`);
  console.log(`  - Archivos: ${sessionMetadata.fileCount}`);

  // Exportar estado de L2 para auditoría
  const exportedState = agentUserMemory.exportState();
  console.log(`\n✓ Estado de L2 exportado (${Object.keys(exportedState).length} secciones)`);

  // Exportar L1 para respaldo
  projectMemory.exportToJSON('./memory/project_knowledge_backup.json');
  console.log('✓ Backup de L1 creado\n');

  // Cerrar conexión
  projectMemory.close();
  console.log('=== Demostración completada ===');
}

// Ejecutar la demostración
demonstrateIPIVCMemory().catch(err => {
  console.error('Error en la demostración:', err);
  process.exit(1);
});
