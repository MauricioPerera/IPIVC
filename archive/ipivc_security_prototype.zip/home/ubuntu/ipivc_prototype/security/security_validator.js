/**
 * Security Validator Module - IPIVC
 * 
 * Módulo para validar especificaciones de seguridad, clasificar riesgos
 * y gestionar el escalamiento de decisiones en equipos heterogéneos.
 */

class SecurityValidator {
  /**
   * Inicializa el validador de seguridad
   */
  constructor() {
    this.riskLevels = {
      CRITICAL: 'critical',
      HIGH: 'high',
      MEDIUM: 'medium',
      LOW: 'low',
    };

    this.agentLevels = {
      JUNIOR: 'junior',
      SENIOR: 'senior',
    };

    this.escalationReasons = [];
    this.securityGates = {};
  }

  /**
   * Clasifica el nivel de riesgo de una tarea basado en impacto y nivel de expertise
   * @param {number} impactChange - Impacto del cambio (1-3)
   * @param {string} agentLevel - Nivel del agente ('junior' o 'senior')
   * @returns {object} Clasificación de riesgo con detalles
   */
  classifyTaskRisk(impactChange, agentLevel) {
    if (![1, 2, 3].includes(impactChange)) {
      throw new Error('impactChange debe ser 1, 2 o 3');
    }

    if (!Object.values(this.agentLevels).includes(agentLevel)) {
      throw new Error(`agentLevel debe ser ${Object.values(this.agentLevels).join(' o ')}`);
    }

    let riskLevel;

    if (agentLevel === this.agentLevels.SENIOR) {
      if (impactChange === 1) riskLevel = this.riskLevels.LOW;
      else if (impactChange === 2) riskLevel = this.riskLevels.MEDIUM;
      else riskLevel = this.riskLevels.HIGH;
    } else {
      // agentLevel === JUNIOR
      if (impactChange === 1) riskLevel = this.riskLevels.MEDIUM;
      else if (impactChange === 2) riskLevel = this.riskLevels.HIGH;
      else riskLevel = this.riskLevels.CRITICAL;
    }

    return {
      riskLevel,
      impactChange,
      agentLevel,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Determina los security gates requeridos para una tarea según su nivel de riesgo
   * @param {string} riskLevel - Nivel de riesgo de la tarea
   * @returns {object} Security gates por fase IPIVC
   */
  getSecurityGates(riskLevel) {
    const gates = {
      [this.riskLevels.LOW]: {
        planifica: {
          requireSpec: false,
          requireSecuritySpec: false,
          requireSecurityReview: false,
        },
        implementa: {
          allowDirectImplementation: true,
          requireFeatureBranch: false,
        },
        verifica: {
          requireLinter: true,
          requireUnitTests: true,
          requireSAST: false,
          requireManualReview: false,
          requireSecurityReview: false,
        },
        corrige: {
          allowDirectFix: true,
          requireReVerification: false,
        },
      },
      [this.riskLevels.MEDIUM]: {
        planifica: {
          requireSpec: true,
          requireSecuritySpec: false,
          requireSecurityReview: false,
        },
        implementa: {
          allowDirectImplementation: true,
          requireFeatureBranch: false,
        },
        verifica: {
          requireLinter: true,
          requireUnitTests: true,
          requireSAST: true,
          requireManualReview: false,
          requireSecurityReview: false,
        },
        corrige: {
          allowDirectFix: true,
          requireReVerification: true,
        },
      },
      [this.riskLevels.HIGH]: {
        planifica: {
          requireSpec: true,
          requireSecuritySpec: true,
          requireSecurityReview: false,
        },
        implementa: {
          allowDirectImplementation: true,
          requireFeatureBranch: false,
        },
        verifica: {
          requireLinter: true,
          requireUnitTests: true,
          requireSAST: true,
          requireManualReview: true,
          requireSecurityReview: false,
        },
        corrige: {
          allowDirectFix: false,
          requireReVerification: true,
        },
      },
      [this.riskLevels.CRITICAL]: {
        planifica: {
          requireSpec: true,
          requireSecuritySpec: true,
          requireSecurityReview: true,
          requireSecurityChampionApproval: true,
        },
        implementa: {
          allowDirectImplementation: false,
          requireFeatureBranch: true,
          prohibitDirectMergeToMain: true,
        },
        verifica: {
          requireLinter: true,
          requireUnitTests: true,
          requireSAST: true,
          requireDASTIfApplicable: true,
          requireManualReview: true,
          requireSecurityReview: true,
          requireSecurityChampionApproval: true,
        },
        corrige: {
          allowDirectFix: false,
          requireSupervisedFix: true,
          requireReVerification: true,
          requireSecurityChampionApproval: true,
        },
      },
    };

    return gates[riskLevel] || null;
  }

  /**
   * Valida que una especificación de seguridad cumpla con los requisitos mínimos
   * @param {object} securitySpec - Objeto con la especificación de seguridad
   * @returns {object} Resultado de validación con errores y advertencias
   */
  validateSecuritySpec(securitySpec) {
    const errors = [];
    const warnings = [];

    // Validar estructura básica
    if (!securitySpec.systemModeling) {
      errors.push('Falta la sección "systemModeling"');
    } else {
      if (!securitySpec.systemModeling.components) {
        errors.push('systemModeling debe incluir "components"');
      }
      if (!securitySpec.systemModeling.dataFlows) {
        errors.push('systemModeling debe incluir "dataFlows"');
      }
      if (!securitySpec.systemModeling.entryPoints) {
        errors.push('systemModeling debe incluir "entryPoints"');
      }
    }

    // Validar análisis de amenazas
    if (!securitySpec.threatAnalysis) {
      errors.push('Falta la sección "threatAnalysis"');
    } else {
      const requiredThreats = ['spoofing', 'tampering', 'repudiation', 'informationDisclosure', 'denialOfService', 'elevationOfPrivilege'];
      const providedThreats = Object.keys(securitySpec.threatAnalysis);

      const missingThreats = requiredThreats.filter(t => !providedThreats.includes(t));
      if (missingThreats.length > 0) {
        warnings.push(`Amenazas STRIDE no completamente documentadas: ${missingThreats.join(', ')}`);
      }
    }

    // Validar requisitos de seguridad no funcionales
    if (!securitySpec.securityRequirements || securitySpec.securityRequirements.length === 0) {
      errors.push('Debe haber al menos un requisito de seguridad no funcional (RSNF)');
    } else {
      securitySpec.securityRequirements.forEach((req, idx) => {
        if (!req.id || !req.description || !req.verificationCriteria) {
          errors.push(`RSNF ${idx + 1}: Falta id, description o verificationCriteria`);
        }
      });
    }

    // Validar checklist de vulnerabilidades
    if (!securitySpec.vulnerabilityChecklist) {
      warnings.push('No se proporcionó un checklist de vulnerabilidades OWASP');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Registra un evento de escalamiento de seguridad
   * @param {object} escalationEvent - Evento de escalamiento
   */
  recordEscalation(escalationEvent) {
    const event = {
      id: `escalation_${Date.now()}`,
      taskId: escalationEvent.taskId,
      reason: escalationEvent.reason, // 'critical_risk', 'verification_failure', 'unknown_threat'
      agentId: escalationEvent.agentId,
      assignedTo: escalationEvent.assignedTo || 'security_champion_queue',
      status: 'open', // 'open', 'in_progress', 'resolved'
      resolution: null,
      createdAt: new Date().toISOString(),
      resolvedAt: null,
    };

    this.escalationReasons.push(event);
    return event;
  }

  /**
   * Resuelve un evento de escalamiento
   * @param {string} escalationId - ID del evento de escalamiento
   * @param {object} resolution - Objeto con detalles de la resolución
   */
  resolveEscalation(escalationId, resolution) {
    const event = this.escalationReasons.find(e => e.id === escalationId);

    if (!event) {
      throw new Error(`Escalamiento con id ${escalationId} no encontrado`);
    }

    event.status = 'resolved';
    event.resolution = resolution;
    event.resolvedAt = new Date().toISOString();

    return event;
  }

  /**
   * Obtiene todos los escalamientos abiertos
   * @returns {array} Lista de escalamientos abiertos
   */
  getOpenEscalations() {
    return this.escalationReasons.filter(e => e.status === 'open');
  }

  /**
   * Valida que una tarea cumpla con los security gates requeridos
   * @param {object} task - Objeto con información de la tarea
   * @param {string} phase - Fase IPIVC ('planifica', 'implementa', 'verifica', 'corrige')
   * @returns {object} Resultado de validación
   */
  validateSecurityGates(task, phase) {
    const gates = this.getSecurityGates(task.riskLevel);

    if (!gates) {
      return { isValid: false, errors: ['Nivel de riesgo desconocido'] };
    }

    const phaseGates = gates[phase];
    const errors = [];

    if (phase === 'planifica') {
      if (phaseGates.requireSpec && !task.spec) {
        errors.push('Se requiere un spec.md para esta tarea');
      }
      if (phaseGates.requireSecuritySpec && !task.securitySpec) {
        errors.push('Se requiere un security.spec.md para esta tarea');
      }
      if (phaseGates.requireSecurityReview && !task.securityReviewApproved) {
        errors.push('Se requiere aprobación de revisión de seguridad');
      }
      if (phaseGates.requireSecurityChampionApproval && !task.securityChampionApproved) {
        errors.push('Se requiere aprobación del Security Champion');
      }
    }

    if (phase === 'implementa') {
      if (!phaseGates.allowDirectImplementation && !task.featureBranch) {
        errors.push('Se requiere un feature branch para esta tarea');
      }
    }

    if (phase === 'verifica') {
      if (phaseGates.requireLinter && !task.linterPassed) {
        errors.push('El linter debe pasar antes de proceder');
      }
      if (phaseGates.requireSAST && !task.sastCompleted) {
        errors.push('Se requiere análisis SAST');
      }
      if (phaseGates.requireManualReview && !task.manualReviewCompleted) {
        errors.push('Se requiere revisión manual de código');
      }
      if (phaseGates.requireSecurityReview && !task.securityReviewCompleted) {
        errors.push('Se requiere revisión de seguridad');
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      phase,
      riskLevel: task.riskLevel,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Genera un reporte de seguridad para una tarea
   * @param {object} task - Objeto con información de la tarea
   * @returns {object} Reporte de seguridad
   */
  generateSecurityReport(task) {
    const report = {
      taskId: task.id,
      riskLevel: task.riskLevel,
      agentLevel: task.agentLevel,
      impactChange: task.impactChange,
      phases: {
        planifica: this.validateSecurityGates(task, 'planifica'),
        implementa: this.validateSecurityGates(task, 'implementa'),
        verifica: this.validateSecurityGates(task, 'verifica'),
        corrige: this.validateSecurityGates(task, 'corrige'),
      },
      escalations: this.escalationReasons.filter(e => e.taskId === task.id),
      generatedAt: new Date().toISOString(),
    };

    return report;
  }
}

module.exports = SecurityValidator;
