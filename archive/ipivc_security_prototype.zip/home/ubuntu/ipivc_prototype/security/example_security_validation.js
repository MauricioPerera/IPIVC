/**
 * Ejemplo de Uso del Módulo de Validación de Seguridad - IPIVC
 * 
 * Demuestra cómo usar el SecurityValidator para clasificar riesgos,
 * validar especificaciones de seguridad y gestionar escalamientos.
 */

const SecurityValidator = require('./security_validator');

async function demonstrateSecurityValidation() {
  console.log('=== Demostración del Módulo de Validación de Seguridad IPIVC ===\n');

  const validator = new SecurityValidator();

  // ========== CASO 1: Tarea de Riesgo Bajo ==========
  console.log('--- CASO 1: Tarea de Riesgo Bajo ---');
  console.log('Escenario: Un agente senior corrige estilos CSS\n');

  const lowRiskTask = {
    id: 'task_001',
    name: 'Corregir estilos CSS del header',
    impactChange: 1, // Bajo
    agentLevel: 'senior',
  };

  const lowRiskClassification = validator.classifyTaskRisk(
    lowRiskTask.impactChange,
    lowRiskTask.agentLevel
  );

  console.log(`Clasificación de Riesgo: ${lowRiskClassification.riskLevel}`);
  const lowRiskGates = validator.getSecurityGates(lowRiskClassification.riskLevel);
  console.log(`Security Gates - Planifica:`);
  console.log(`  - Requiere spec.md: ${lowRiskGates.planifica.requireSpec}`);
  console.log(`  - Requiere security.spec.md: ${lowRiskGates.planifica.requireSecuritySpec}`);
  console.log(`Security Gates - Verifica:`);
  console.log(`  - Requiere SAST: ${lowRiskGates.verifica.requireSAST}`);
  console.log(`  - Requiere revisión manual: ${lowRiskGates.verifica.requireManualReview}\n`);

  // ========== CASO 2: Tarea de Riesgo Crítico ==========
  console.log('--- CASO 2: Tarea de Riesgo Crítico ---');
  console.log('Escenario: Un agente junior implementa un nuevo sistema de autenticación\n');

  const criticalRiskTask = {
    id: 'task_002',
    name: 'Implementar autenticación con JWT',
    impactChange: 3, // Alto
    agentLevel: 'junior',
  };

  const criticalRiskClassification = validator.classifyTaskRisk(
    criticalRiskTask.impactChange,
    criticalRiskTask.agentLevel
  );

  console.log(`Clasificación de Riesgo: ${criticalRiskClassification.riskLevel}`);
  const criticalRiskGates = validator.getSecurityGates(criticalRiskClassification.riskLevel);
  console.log(`Security Gates - Planifica:`);
  console.log(`  - Requiere spec.md: ${criticalRiskGates.planifica.requireSpec}`);
  console.log(`  - Requiere security.spec.md: ${criticalRiskGates.planifica.requireSecuritySpec}`);
  console.log(`  - Requiere aprobación Security Champion: ${criticalRiskGates.planifica.requireSecurityChampionApproval}`);
  console.log(`Security Gates - Implementa:`);
  console.log(`  - Requiere feature branch: ${criticalRiskGates.implementa.requireFeatureBranch}`);
  console.log(`  - Prohibe merge directo a main: ${criticalRiskGates.implementa.prohibitDirectMergeToMain}`);
  console.log(`Security Gates - Verifica:`);
  console.log(`  - Requiere DAST: ${criticalRiskGates.verifica.requireDASTIfApplicable}`);
  console.log(`  - Requiere aprobación Security Champion: ${criticalRiskGates.verifica.requireSecurityChampionApproval}\n`);

  // ========== CASO 3: Validación de Especificación de Seguridad ==========
  console.log('--- CASO 3: Validación de Especificación de Seguridad ---\n');

  const validSecuritySpec = {
    systemModeling: {
      components: ['auth-service', 'user-db', 'api-gateway'],
      dataFlows: [
        { from: 'client', to: 'api-gateway', data: 'credentials' },
        { from: 'api-gateway', to: 'auth-service', data: 'credentials' },
      ],
      entryPoints: ['POST /api/auth/login'],
    },
    threatAnalysis: {
      spoofing: 'Un atacante podría adivinar credenciales (fuerza bruta)',
      tampering: 'Un atacante podría interceptar el JWT si no se usa HTTPS',
      repudiation: 'N/A',
      informationDisclosure: 'Respuestas de error detalladas podrían revelar si un email existe',
      denialOfService: 'Un atacante podría hacer múltiples intentos de login',
      elevationOfPrivilege: 'N/A',
    },
    securityRequirements: [
      {
        id: 'RSNF-01',
        description: 'Mitigación de fuerza bruta',
        verificationCriteria: 'Bloqueo de cuenta después de 5 intentos fallidos',
      },
      {
        id: 'RSNF-02',
        description: 'Comunicación segura',
        verificationCriteria: 'Forzar HTTPS para todos los endpoints de login',
      },
    ],
    vulnerabilityChecklist: {
      'A02:Cryptographic Failures': true,
      'A07:Identification and Authentication Failures': true,
    },
  };

  const validationResult = validator.validateSecuritySpec(validSecuritySpec);
  console.log(`Especificación válida: ${validationResult.isValid}`);
  console.log(`Errores: ${validationResult.errors.length}`);
  console.log(`Advertencias: ${validationResult.warnings.length}`);
  if (validationResult.warnings.length > 0) {
    console.log(`  - ${validationResult.warnings.join('\n  - ')}`);
  }
  console.log();

  // ========== CASO 4: Escalamiento de Seguridad ==========
  console.log('--- CASO 4: Escalamiento de Seguridad ---\n');

  const escalation = validator.recordEscalation({
    taskId: 'task_002',
    reason: 'critical_risk',
    agentId: 'agent_junior_001',
  });

  console.log(`Escalamiento registrado:`);
  console.log(`  - ID: ${escalation.id}`);
  console.log(`  - Razón: ${escalation.reason}`);
  console.log(`  - Estado: ${escalation.status}`);
  console.log(`  - Asignado a: ${escalation.assignedTo}\n`);

  // Resolver el escalamiento
  const resolution = validator.resolveEscalation(escalation.id, {
    action: 'pair_vibecoding',
    securityChampion: 'agent_senior_001',
    notes: 'Se realizará pair programming para implementar correctamente la autenticación',
  });

  console.log(`Escalamiento resuelto:`);
  console.log(`  - Estado: ${resolution.status}`);
  console.log(`  - Resolución: ${resolution.resolution.action}`);
  console.log(`  - Security Champion: ${resolution.resolution.securityChampion}\n`);

  // ========== CASO 5: Validación de Security Gates ==========
  console.log('--- CASO 5: Validación de Security Gates ---\n');

  const taskToValidate = {
    id: 'task_003',
    name: 'Implementar nueva funcionalidad de pago',
    riskLevel: 'high',
    agentLevel: 'senior',
    impactChange: 2,
    spec: true,
    securitySpec: true,
    linterPassed: true,
    sastCompleted: true,
    manualReviewCompleted: true,
    securityReviewCompleted: false, // Falta esto
  };

  const gateValidation = validator.validateSecurityGates(taskToValidate, 'verifica');
  console.log(`Validación de Security Gates para fase 'verifica':`);
  console.log(`  - Válido: ${gateValidation.isValid}`);
  console.log(`  - Errores: ${gateValidation.errors.length}`);
  if (gateValidation.errors.length > 0) {
    console.log(`    ${gateValidation.errors.join('\n    ')}`);
  }
  console.log();

  // ========== CASO 6: Reporte de Seguridad ==========
  console.log('--- CASO 6: Reporte de Seguridad ---\n');

  const report = validator.generateSecurityReport(taskToValidate);
  console.log(`Reporte de Seguridad para tarea ${report.taskId}:`);
  console.log(`  - Nivel de Riesgo: ${report.riskLevel}`);
  console.log(`  - Nivel de Agente: ${report.agentLevel}`);
  console.log(`  - Impacto del Cambio: ${report.impactChange}`);
  console.log(`  - Fase Planifica - Válido: ${report.phases.planifica.isValid}`);
  console.log(`  - Fase Implementa - Válido: ${report.phases.implementa.isValid}`);
  console.log(`  - Fase Verifica - Válido: ${report.phases.verifica.isValid}`);
  console.log(`  - Fase Corrige - Válido: ${report.phases.corrige.isValid}`);
  console.log(`  - Escalamientos: ${report.escalations.length}\n`);

  console.log('=== Demostración completada ===');
}

// Ejecutar la demostración
demonstrateSecurityValidation().catch(err => {
  console.error('Error en la demostración:', err);
  process.exit(1);
});
