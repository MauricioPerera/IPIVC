# L1 Project Knowledge (LokiVector)

Este archivo almacena el conocimiento persistente del proyecto.
Debe ser actualizado manualmente por el **Humano Responsable** al finalizar hitos importantes, consolidando los aprendizajes de sus sesiones con IA.

## Arquitectura
[Describir arquitectura]

## Decisiones Clave
- [Fecha]: [Decisión]

## Convenciones
- [Convención 1]
